/*
Author:  Kevin Blum
Class:   240-02
Assignment:  Lab
Date Assigned: 1/29/15
Due Date: 2/5/15
Description: 

Certification of Authenticity:  I certify that this is entirely my own work, except where I have given fully-documented references to the work of others. 
I understand the definition and consequences of plagiarism and acknowledge that the assessor of this assignment may, for the purpose of assessing this assignment: 
- Reproduce this assignment and provide a copy to another member of academic staff; and/or 
- Communicate a copy of this assignment to a plagiarism checking service (which may then retain a copy of this assignment on its database for the purpose of future plagiarism checking

*/



#include "ship.h"


Ship::Ship(){

   mBays = 0;
   mLatrines = 0;
   mBridges = 0;
   mCabins = 0;

}

Ship::Ship(int bays, int latrines, int bridges, int cabins){

   mBays = bays;
   mLatrines = latrines;
   mBridges = bridges;
   mCabins = cabins;

}

bool Ship::isValid(){

   int area = breadth * width;

   if (height >= minHeight && area >= minArea )
      return true;
   else 
      return false;

}

void Ship::constructRoom(Room[], int, RoomType(type), int width, int breadth, int height){


   Room::getRoomName;

   if (ROOM_STRINGS[NUM_ROOM_TYPES] == "Bay")
      mBays += 1;
   else if (ROOM_STRINGS[NUM_ROOM_TYPES] == "Latrine")
      mLatrines += 1;
   else if (ROOM_STRINGS[NUM_ROOM_TYPES] == "Bridge")
      mBridges += 1;
   else if (ROOM_STRINGS[NUM_ROOM_TYPES] == "Cabin")
      mCabins += 1;
       
   Room::getBreadth;
   Room::getWidth;
   Room::getHeight;

}


bool Ship::addRoom(const Room& theRoom){

   void constructRoom(Room[], int, RoomType, int, int, int);

   isValid();

   
}