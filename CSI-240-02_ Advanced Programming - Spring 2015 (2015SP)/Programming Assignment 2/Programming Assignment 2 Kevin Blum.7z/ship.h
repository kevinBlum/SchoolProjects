/*
Author:  Kevin Blum
Class:   240-02
Assignment:  Lab
Date Assigned: 1/29/15
Due Date: 2/5/15
Description:

Certification of Authenticity:  I certify that this is entirely my own work, except where I have given fully-documented references to the work of others.
I understand the definition and consequences of plagiarism and acknowledge that the assessor of this assignment may, for the purpose of assessing this assignment:
- Reproduce this assignment and provide a copy to another member of academic staff; and/or
- Communicate a copy of this assignment to a plagiarism checking service (which may then retain a copy of this assignment on its database for the purpose of future plagiarism checking

*/

#include "room.cpp"
#include <sstream>
#include <string>

using namespace std;


class Ship{

public:

   //default constructor
   Ship();
   //constructor
   Ship(int bays, int latrines, int bridges, int cabins);
   //destructor
   ~Ship(){};

   bool addRoom(const Room& theRoom);
   inline int getNumBays() const { return mBays; };
   inline int getNumLatrines() const { return mLatrines; };
   inline int getNumBridges() const { return mBridges; };
   inline int getNumCabins() const { return mCabins; };
   int getTotalSquareFootage();
   bool isValid();
   string getDescription();


private:

   void constructRoom(Room[], int, RoomType, int, int, int);

   int mBays, mLatrines, mBridges, mCabins;
   const int roomMIN = 1, roomMAX = 10, minHeight = 7, minArea = 20, maxBridges = 1;
};

