/*
 * main.c
 *
 *  Created on: Sep 21, 2015
 *      Author: kevin
 */
#include "csi230wrapper.h"

int main(){

	//declaration of character array to make the string
	char words[100];

	printf("What would you like to output?\n");

	//function call to pull input from the user, gets is used to obtain strings with spaces
	gets(words);

	//function call to function created in wrapper that prints out the string given
	writestring(words);



return 0;
}

