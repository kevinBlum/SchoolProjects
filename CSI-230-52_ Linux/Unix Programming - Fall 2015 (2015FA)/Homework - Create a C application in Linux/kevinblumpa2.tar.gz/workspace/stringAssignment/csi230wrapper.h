/*
 * csi230wrapper.h
 *
 *  Created on: Sep 19, 2015
 *      Author: kevin
 */

#ifndef CSI230WRAPPER_H_
#define CSI230WRAPPER_H_

#include <stdio.h>
#include <string.h>


//function created to print out the given string
int writestring(char words[100]){

	//print function to output given string
	printf("%s\n", words);

	return 0;
}

#endif /* CSI230WRAPPER_H_ */
